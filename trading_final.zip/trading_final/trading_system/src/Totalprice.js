const Totalprice = ({ total }) => {
    return (

        <>
        <label>Totalprice : { total }</label>
        </>
    );
}
export default Totalprice;